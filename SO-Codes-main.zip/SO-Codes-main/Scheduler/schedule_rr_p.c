#include "schedule_rr_p.h"

// add a task to the list 
void add(char *name, int priority, int burst){
   int x = 0;
}

// invoke the scheduler
void schedule(){
   int x = 0;
}
